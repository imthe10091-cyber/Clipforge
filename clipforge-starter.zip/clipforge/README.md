# ClipForge — AI livestream clipping starter

## Included
- Next.js dashboard with streamer watchlist, candidate review and MP4 download view
- FastAPI endpoints for streamers, streams, clips, edits, render jobs and job status
- PostgreSQL SQLAlchemy models for streamers, streams, clips, edits, render jobs and exports
- Redis/Celery background render queue
- Chat velocity, emote-density, RMS audio-spike and signal-fusion candidate scoring
- Optional injected LLM scorer interface
- OpenCV face-center heuristic and FFmpeg 9:16 render with loudness normalization and SRT burn-in support

## Run locally
Requires Docker Desktop.

```bash
cd infra
docker compose up --build
```
- Web: http://localhost:3000
- API docs: http://localhost:8000/docs
- Health: http://localhost:8000/health

## Add source media for a test render
The schema expects `streams.source_uri` to point to a local file visible inside both API and worker containers (under `/data`). Create a Stream and CandidateClip row through a one-off Python shell or admin endpoint, then POST `/clips/{id}/render`.

## Important implementation boundaries
This is a runnable foundation, not a turnkey stream scraper. Platform-specific OAuth, webhook/EventSub subscriptions, chat ingestion, VOD discovery, rolling segment capture, Whisper transcription, LLM provider integration, caption word alignment, SRT generation, and S3 upload are intentionally adapter seams. Implement these using platform-approved access and creator permissions. Do not assume a platform permits downloading or retaining every stream. Secure credentials, add user authentication/authorization, signed media URLs, quotas, retention controls, Alembic migrations, structured logging and observability before exposing this to users.

## Detection usage
`app.detection` accepts normalized timestamped chat messages, a decoded audio waveform and transcript segments. It proposes 15–60 second windows. The current audio feature is an RMS loudness proxy, not a laughter classifier. The LLM adapter is dependency-injected and falls back to the preliminary score when no client is supplied.

## Render usage
`app.renderer.render_vertical(source, output, start, end, srt_path=None)` crops to 9:16, scales to 1080x1920, applies FFmpeg loudnorm and optionally burns SRT captions. Face detection is a simple Haar-cascade heuristic; production tracking should use a robust detector/tracker and source-specific layout templates. Split facecam/gameplay layouts require separate source tracks or segmentation.
