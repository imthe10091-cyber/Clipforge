import './style.css';
export const metadata = { title: 'ClipForge', description: 'AI livestream clipping workspace' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
