from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from .db import Base, engine, SessionLocal
from .models import Streamer, Stream, CandidateClip, ClipEdit, RenderJob
from .tasks import render_clip
from .queue import celery
from pathlib import Path

Base.metadata.create_all(bind=engine)
app = FastAPI(title="ClipForge API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

class StreamerIn(BaseModel):
    platform: str = Field(pattern="^(twitch|youtube|kick)$")
    username: str = Field(min_length=1, max_length=120)
    external_id: str | None = None

class ClipEditIn(BaseModel):
    trim_start: float = Field(ge=0)
    trim_end: float = Field(gt=0)
    caption_style: str = "karaoke"
    layout_preset: str = "center"
    facecam_enabled: bool = True
    captions: list[dict] = []

@app.get("/health")
def health(): return {"ok": True}

@app.get("/streamers")
def list_streamers(db: Session = Depends(get_db)):
    return [{"id": x.id, "platform": x.platform, "username": x.username, "enabled": x.enabled} for x in db.query(Streamer).all()]

@app.post("/streamers", status_code=201)
def add_streamer(payload: StreamerIn, db: Session = Depends(get_db)):
    row = Streamer(**payload.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, "platform": row.platform, "username": row.username}

@app.delete("/streamers/{streamer_id}")
def remove_streamer(streamer_id: int, db: Session = Depends(get_db)):
    row = db.get(Streamer, streamer_id)
    if not row: raise HTTPException(404, "Streamer not found")
    db.delete(row); db.commit(); return {"deleted": streamer_id}

@app.get("/streams")
def list_streams(db: Session = Depends(get_db)):
    return [{"id": s.id, "streamer_id": s.streamer_id, "title": s.title, "status": s.status, "source_uri": s.source_uri} for s in db.query(Stream).order_by(Stream.id.desc()).limit(100).all()]

@app.get("/clips")
def list_clips(db: Session = Depends(get_db)):
    return [{"id": c.id, "stream_id": c.stream_id, "start_seconds": c.start_seconds, "end_seconds": c.end_seconds,
             "virality_score": c.virality_score, "title": c.title, "transcript": c.transcript, "status": c.status}
            for c in db.query(CandidateClip).order_by(CandidateClip.virality_score.desc()).limit(200).all()]

@app.put("/clips/{clip_id}/edit")
def edit_clip(clip_id: int, payload: ClipEditIn, db: Session = Depends(get_db)):
    clip = db.get(CandidateClip, clip_id)
    if not clip: raise HTTPException(404, "Clip not found")
    if payload.trim_end <= payload.trim_start or payload.trim_end-payload.trim_start > 60: raise HTTPException(422, "Trim must be 0-60 seconds")
    edit = ClipEdit(clip_id=clip_id, **payload.model_dump()); db.add(edit); db.commit(); db.refresh(edit)
    return {"edit_id": edit.id, "clip_id": clip_id}

@app.post("/clips/{clip_id}/render", status_code=202)
def queue_render(clip_id: int, db: Session = Depends(get_db)):
    clip = db.get(CandidateClip, clip_id)
    if not clip: raise HTTPException(404, "Clip not found")
    job = RenderJob(clip_id=clip_id, status="queued", progress=0); db.add(job); db.commit(); db.refresh(job)
    task = render_clip.delay(job.id); job.celery_task_id = task.id; db.commit()
    return {"job_id": job.id, "task_id": task.id, "status": "queued"}

@app.get("/jobs/{job_id}")
def get_job(job_id: int, db: Session = Depends(get_db)):
    job = db.get(RenderJob, job_id)
    if not job: raise HTTPException(404, "Job not found")
    return {"id": job.id, "status": job.status, "progress": job.progress, "output_uri": job.output_uri, "error": job.error}

@app.get("/clips/{clip_id}/download")
def download_clip(clip_id: int, db: Session = Depends(get_db)):
    job = db.query(RenderJob).filter_by(clip_id=clip_id, status="completed").order_by(RenderJob.id.desc()).first()
    if not job or not job.output_uri or not Path(job.output_uri).exists(): raise HTTPException(404, "Rendered clip unavailable")
    return FileResponse(job.output_uri, media_type="video/mp4", filename=f"clip-{clip_id}.mp4")

@app.websocket("/ws/jobs/{job_id}")
async def job_updates(ws: WebSocket, job_id: int):
    await ws.accept()
    try:
        while True:
            db = SessionLocal()
            try:
                job = db.get(RenderJob, job_id)
                if not job: await ws.send_json({"error": "not found"}); break
                await ws.send_json({"id": job.id, "status": job.status, "progress": job.progress, "error": job.error})
                if job.status in ("completed", "failed"): break
            finally: db.close()
            await ws.receive_text()  # client sends periodic heartbeat
    except WebSocketDisconnect: pass
