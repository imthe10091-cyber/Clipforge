"""FFmpeg renderer for 9:16 clips. Captions use SRT/ASS-compatible timestamps."""
from pathlib import Path
import subprocess
import cv2

def detect_face_center(video_path: str, start: float, sample_seconds: float = 1.0) -> float | None:
    cap = cv2.VideoCapture(video_path)
    cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
    ok, frame = cap.read(); cap.release()
    if not ok: return None
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
    if len(faces) == 0: return None
    x, y, w, h = max(faces, key=lambda r: r[2]*r[3])
    return (x + w/2) / frame.shape[1]

def render_vertical(source: str, output: str, start: float, end: float,
                    srt_path: str | None = None, layout: str = "center",
                    facecam_enabled: bool = True) -> str:
    if not (0 <= start < end) or end-start > 60:
        raise ValueError("Clip must be between 0 and 60 seconds with valid timestamps")
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    center = detect_face_center(source, start) if facecam_enabled else None
    # For standard gameplay, scale-to-fill and crop around detected face when possible.
    # Production layouts should use separate facecam/gameplay source tracks when available.
    crop_x = "(iw-ih*9/16)/2"
    if center is not None:
        crop_x = f"max(0,min(iw-ih*9/16,{center:.4f}*iw-ih*9/32))"
    filters = [f"crop='ih*9/16:ih:{crop_x}:0", "scale=1080:1920:flags=lanczos",
               "setsar=1", "fps=30", "format=yuv420p"]
    if srt_path:
        escaped = str(Path(srt_path).resolve()).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
        filters.append(f"subtitles='{escaped}':force_style='FontName=Arial,FontSize=18,Outline=2,Alignment=2,MarginV=150'" )
    cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", source, "-t", str(end-start),
           "-vf", ",".join(filters), "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-c:a", "aac", "-b:a", "192k", output]
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    return output
