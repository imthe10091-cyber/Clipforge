from datetime import datetime, timezone
from pathlib import Path
from .queue import celery
from .db import SessionLocal
from .models import RenderJob, CandidateClip, ClipEdit
from .config import settings
from .renderer import render_vertical

@celery.task(bind=True)
def render_clip(self, job_id: int):
    db = SessionLocal()
    try:
        job = db.get(RenderJob, job_id)
        if not job: return {"error": "job not found"}
        clip = db.get(CandidateClip, job.clip_id)
        stream = clip.stream
        edit = clip.edits[-1] if clip.edits else None
        source = stream.source_uri
        if not source or not Path(source).exists(): raise FileNotFoundError(f"Source media unavailable: {source}")
        start = edit.trim_start if edit else clip.start_seconds
        end = edit.trim_end if edit else clip.end_seconds
        job.status = "running"; job.progress = 10; db.commit()
        output = str(Path(settings.media_root) / "renders" / f"clip-{clip.id}-job-{job.id}.mp4")
        render_vertical(source, output, start, end,
                        layout=edit.layout_preset if edit else "center",
                        facecam_enabled=edit.facecam_enabled if edit else True)
        job.status = "completed"; job.progress = 100; job.output_uri = output
        job.completed_at = datetime.now(timezone.utc); db.commit()
        return {"job_id": job.id, "output": output}
    except Exception as exc:
        db.rollback()
        job = db.get(RenderJob, job_id)
        if job: job.status = "failed"; job.error = str(exc); db.commit()
        raise
    finally: db.close()
