"""Signal fusion primitives. Inputs are timestamped; all scores are normalized 0..1."""
from collections import defaultdict
import numpy as np

def chat_velocity(messages: list[dict], window_seconds: int = 5) -> list[dict]:
    """messages: [{timestamp: float, text: str}]. Return 1-second bins with rates."""
    if not messages: return []
    bins = defaultdict(list)
    for msg in messages: bins[int(float(msg["timestamp"]))].append(msg.get("text", ""))
    out = []
    for second in range(min(bins), max(bins) + 1):
        window = [t for s in range(second-window_seconds+1, second+1) for t in bins[s]]
        emotes = sum(1 for t in window if len(t.strip()) <= 24 and (t.isupper() or len(t.split()) <= 2))
        rate = len(window) / window_seconds
        out.append({"timestamp": second, "messages_per_second": rate,
                    "emote_density": emotes / max(1, len(window))})
    return out

def audio_spikes(waveform: np.ndarray, sample_rate: int, hop_seconds: float = 1.0) -> list[dict]:
    """RMS loudness proxy. Production: add speech/laughter classifier and calibrated LUFS."""
    x = np.asarray(waveform, dtype=np.float32).flatten()
    hop = max(1, int(sample_rate * hop_seconds))
    rms = [float(np.sqrt(np.mean(x[i:i+hop]**2) + 1e-12)) for i in range(0, len(x), hop)]
    if not rms: return []
    db = 20 * np.log10(np.maximum(rms, 1e-8))
    baseline = float(np.median(db)); spread = float(np.median(np.abs(db-baseline)) * 1.4826 + 1e-6)
    return [{"timestamp": i*hop_seconds, "rms_db": float(v),
             "spike_score": float(np.clip((v-baseline)/(4*spread), 0, 1))} for i, v in enumerate(db)]

def fuse_candidates(chat: list[dict], audio: list[dict], transcript_segments: list[dict],
                    duration: int = 30, threshold: float = 0.55) -> list[dict]:
    """Sliding-window candidate proposals; LLM semantic score is added separately."""
    if not chat and not audio: return []
    end = max([x["timestamp"] for x in chat] + [x["timestamp"] for x in audio])
    proposals = []
    for start in range(0, int(end)+1, max(5, duration//2)):
        stop = start + duration
        c = [x for x in chat if start <= x["timestamp"] < stop]
        a = [x for x in audio if start <= x["timestamp"] < stop]
        chat_score = min(1.0, max([x["messages_per_second"] for x in c], default=0) / 8)
        emote_score = float(np.mean([x["emote_density"] for x in c])) if c else 0
        audio_score = max([x["spike_score"] for x in a], default=0)
        segments = [x for x in transcript_segments if start <= x.get("start", 0) < stop]
        text = " ".join(x.get("text", "") for x in segments).strip()
        score = .40*chat_score + .15*emote_score + .30*audio_score + .15*min(1, len(text)/240)
        if score >= threshold:
            proposals.append({"start_seconds": start, "end_seconds": stop,
                              "signals": {"chat": chat_score, "emotes": emote_score, "audio": audio_score},
                              "transcript": text, "preliminary_score": round(score, 4)})
    return sorted(proposals, key=lambda x: x["preliminary_score"], reverse=True)

def score_with_llm(candidate: dict, llm_client=None) -> dict:
    """Provider-neutral hook. Inject an LLM client; never trust generated JSON without validation."""
    if llm_client is None:
        candidate["virality_score"] = candidate["preliminary_score"]
        candidate["title"] = "Untitled moment"
        candidate["hashtags"] = []
        return candidate
    prompt = ("Score this short livestream moment from 0 to 1 for standalone short-form appeal. "
              "Consider hook, payoff, context and clarity. Return JSON keys score,title,description,hashtags.\n" + candidate.get("transcript", ""))
    result = llm_client(prompt)
    score = max(0.0, min(1.0, float(result.get("score", 0))))
    candidate.update(virality_score=score, title=str(result.get("title", "Untitled"))[:240],
                     description=str(result.get("description", "")), hashtags=list(result.get("hashtags", []))[:12])
    return candidate
