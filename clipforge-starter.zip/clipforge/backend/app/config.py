from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://clipforge:clipforge@db:5432/clipforge"
    redis_url: str = "redis://redis:6379/0"
    media_root: str = "/data"
    llm_api_key: str | None = None
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
