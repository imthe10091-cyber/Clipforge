from datetime import datetime, timezone
from sqlalchemy import String, Integer, Float, Boolean, DateTime, ForeignKey, Text, JSON, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def now(): return datetime.now(timezone.utc)

class Streamer(Base):
    __tablename__ = "streamers"
    id: Mapped[int] = mapped_column(primary_key=True)
    platform: Mapped[str] = mapped_column(String(24), index=True)
    username: Mapped[str] = mapped_column(String(120))
    external_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    streams: Mapped[list["Stream"]] = relationship(back_populates="streamer", cascade="all, delete-orphan")
    __table_args__ = (Index("uq_streamer_platform_external", "platform", "external_id", unique=True),)

class Stream(Base):
    __tablename__ = "streams"
    id: Mapped[int] = mapped_column(primary_key=True)
    streamer_id: Mapped[int] = mapped_column(ForeignKey("streamers.id", ondelete="CASCADE"), index=True)
    external_id: Mapped[str | None] = mapped_column(String(180), nullable=True)
    title: Mapped[str | None] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(24), default="unknown", index=True)
    source_uri: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    streamer: Mapped[Streamer] = relationship(back_populates="streams")
    clips: Mapped[list["CandidateClip"]] = relationship(back_populates="stream", cascade="all, delete-orphan")

class CandidateClip(Base):
    __tablename__ = "candidate_clips"
    id: Mapped[int] = mapped_column(primary_key=True)
    stream_id: Mapped[int] = mapped_column(ForeignKey("streams.id", ondelete="CASCADE"), index=True)
    start_seconds: Mapped[float] = mapped_column(Float)
    end_seconds: Mapped[float] = mapped_column(Float)
    virality_score: Mapped[float] = mapped_column(Float, default=0)
    transcript: Mapped[str | None] = mapped_column(Text)
    title: Mapped[str | None] = mapped_column(String(240))
    description: Mapped[str | None] = mapped_column(Text)
    hashtags: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(24), default="candidate", index=True)
    stream: Mapped[Stream] = relationship(back_populates="clips")
    edits: Mapped[list["ClipEdit"]] = relationship(back_populates="clip", cascade="all, delete-orphan")
    jobs: Mapped[list["RenderJob"]] = relationship(back_populates="clip", cascade="all, delete-orphan")

class ClipEdit(Base):
    __tablename__ = "clip_edits"
    id: Mapped[int] = mapped_column(primary_key=True)
    clip_id: Mapped[int] = mapped_column(ForeignKey("candidate_clips.id", ondelete="CASCADE"), index=True)
    trim_start: Mapped[float] = mapped_column(Float)
    trim_end: Mapped[float] = mapped_column(Float)
    caption_style: Mapped[str] = mapped_column(String(40), default="karaoke")
    layout_preset: Mapped[str] = mapped_column(String(40), default="gameplay")
    facecam_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    captions: Mapped[list] = mapped_column(JSON, default=list)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    clip: Mapped[CandidateClip] = relationship(back_populates="edits")

class RenderJob(Base):
    __tablename__ = "render_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    clip_id: Mapped[int] = mapped_column(ForeignKey("candidate_clips.id", ondelete="CASCADE"), index=True)
    celery_task_id: Mapped[str | None] = mapped_column(String(180))
    status: Mapped[str] = mapped_column(String(24), default="queued", index=True)
    progress: Mapped[int] = mapped_column(Integer, default=0)
    output_uri: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    clip: Mapped[CandidateClip] = relationship(back_populates="jobs")

class Export(Base):
    __tablename__ = "exports"
    id: Mapped[int] = mapped_column(primary_key=True)
    clip_id: Mapped[int] = mapped_column(ForeignKey("candidate_clips.id", ondelete="CASCADE"), index=True)
    format: Mapped[str] = mapped_column(String(12))
    status: Mapped[str] = mapped_column(String(24), default="queued")
    file_uri: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
